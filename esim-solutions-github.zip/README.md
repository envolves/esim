# eSIM Solutions Pakistan — GitHub Pages Website

This project is a static HTML/CSS/JavaScript website designed for GitHub Pages.

## Included

- Responsive homepage
- Non-Expiry eSIM package category
- 30-Day eSIM package category
- Buy Now checkout modal
- Customer details form
- JazzCash payment screen
- QR code image area
- JazzCash account title and number
- Automatic order number
- Instagram contact button
- Copyable order message
- Compatibility warnings
- FAQ
- Mobile-friendly layout

## IMPORTANT: edit your payment/contact details

Open `app.js` and edit this section:

```js
const SITE_CONFIG = {
  instagramUsername: "esimsolutions.pk",
  jazzCashNumber: "03XX XXXXXXX",
  jazzCashAccountTitle: "YOUR ACCOUNT TITLE",
  jazzCashQrPath: "assets/jazzcash-qr-placeholder.svg"
};
```

Replace:

- `esimsolutions.pk` with your Instagram username if different.
- `03XX XXXXXXX` with your JazzCash number.
- `YOUR ACCOUNT TITLE` with the JazzCash account title.
- Replace `assets/jazzcash-qr-placeholder.svg` with your real QR code file.

For example, put your QR code at:

`assets/jazzcash-qr.png`

Then change:

```js
jazzCashQrPath: "assets/jazzcash-qr.png"
```

## Prices

The current package list is based on the image you supplied.

### Non-Expiry
- 3 GB — Rs. 1,200
- 5 GB — Rs. 1,490
- 10 GB — Rs. 2,250
- 20 GB — Rs. 3,599
- 50 GB — Rs. 6,999
- 100 GB — Rs. 11,000

### 30 Days
- 1 GB — Rs. 650
- 3 GB — Rs. 850
- 5 GB — Rs. 1,150
- 10 GB — Rs. 1,750
- 20 GB — Rs. 2,750

Edit the `PACKAGES` object in `app.js` whenever prices change.

## Deploy to GitHub Pages

1. Create a new GitHub repository.
2. Upload:
   - `index.html`
   - `styles.css`
   - `app.js`
   - the `assets` folder
3. Commit the files.
4. In GitHub, open:
   `Settings → Pages`
5. Under **Build and deployment**, choose:
   `Deploy from a branch`
6. Choose:
   - Branch: `main`
   - Folder: `/ (root)`
7. Save.
8. GitHub will give you a public website URL.

## Important limitation of GitHub Pages

GitHub Pages is static hosting. It cannot securely:

- receive uploaded payment screenshots,
- store orders in a central database,
- verify JazzCash payments,
- protect secret API keys,
- send eSIMs automatically.

This version creates the order in the customer's browser and asks them to contact you on Instagram with the generated order number and their payment screenshot.

The browser also saves recent orders in `localStorage`. That is only on the customer's device and is not a merchant database.

If you later want a real admin dashboard, payment-proof upload, automatic email, or payment verification, add a backend such as Supabase/Firebase/Cloudflare Workers or a payment gateway.
